
from __future__ import annotations

import hashlib
import math
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional, Tuple

import librosa
import numpy as np
import pyloudnorm as pyln
import soundfile as sf
from scipy import signal


EPS = 1e-12
A4_NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]


def db20(x: float | np.ndarray, floor: float = -120.0) -> float | np.ndarray:
    value = 20.0 * np.log10(np.maximum(np.asarray(x), EPS))
    if isinstance(value, np.ndarray):
        return np.maximum(value, floor)
    return float(max(value, floor))


def db10(x: float | np.ndarray, floor: float = -140.0) -> float | np.ndarray:
    value = 10.0 * np.log10(np.maximum(np.asarray(x), EPS))
    if isinstance(value, np.ndarray):
        return np.maximum(value, floor)
    return float(max(value, floor))


def safe_float(value: Any, ndigits: int = 3, default: Optional[float] = None) -> Optional[float]:
    try:
        v = float(value)
        if math.isnan(v) or math.isinf(v):
            return default
        return round(v, ndigits)
    except Exception:
        return default


def rms(x: np.ndarray, axis: Optional[int] = None) -> np.ndarray:
    return np.sqrt(np.mean(np.square(x), axis=axis) + EPS)


def peak_dbfs(x: np.ndarray) -> float:
    return float(db20(float(np.max(np.abs(x))) + EPS))


def clamp01(x: float) -> float:
    return float(max(0.0, min(1.0, x)))


@dataclass(frozen=True)
class TargetProfile:
    name: str
    integrated_lufs_min: float
    integrated_lufs_max: float
    true_peak_max_dbtp: float
    crest_factor_min_db: float
    mono_low_hz: float
    low_end_weight: str


TARGET_PROFILES: Dict[str, TargetProfile] = {
    "modern_hiphop_master": TargetProfile(
        name="modern_hiphop_master",
        integrated_lufs_min=-10.5,
        integrated_lufs_max=-8.0,
        true_peak_max_dbtp=-1.0,
        crest_factor_min_db=7.0,
        mono_low_hz=120.0,
        low_end_weight="heavy",
    ),
    "streaming_master": TargetProfile(
        name="streaming_master",
        integrated_lufs_min=-14.5,
        integrated_lufs_max=-11.0,
        true_peak_max_dbtp=-1.0,
        crest_factor_min_db=8.0,
        mono_low_hz=100.0,
        low_end_weight="balanced",
    ),
    "premaster": TargetProfile(
        name="premaster",
        integrated_lufs_min=-20.0,
        integrated_lufs_max=-14.0,
        true_peak_max_dbtp=-6.0,
        crest_factor_min_db=10.0,
        mono_low_hz=120.0,
        low_end_weight="balanced",
    ),
}


class SonicV2Analyzer:
    """
    Sonic AI V2 professional mix/master analyzer.

    Design rule:
    - measure first
    - diagnose second
    - recommend chain third
    - never pretend confidence where measurements are weak
    """

    def __init__(
        self,
        analysis_sr: int = 22050,
        true_peak_oversample: int = 4,
        max_duration_seconds: int = 900,
    ) -> None:
        self.analysis_sr = analysis_sr
        self.true_peak_oversample = true_peak_oversample
        self.max_duration_seconds = max_duration_seconds

    def analyze_file(
        self,
        path: str,
        target_profile: str = "modern_hiphop_master",
        include_debug: bool = False,
    ) -> Dict[str, Any]:
        started = time.perf_counter()
        profile = TARGET_PROFILES.get(target_profile, TARGET_PROFILES["modern_hiphop_master"])

        audio, sr, loader_notes = self._load_audio(path)
        audio = self._limit_duration(audio, sr)
        audio = self._sanitize_audio(audio)

        file_hash = self._hash_file(path)
        duration = audio.shape[0] / float(sr)
        channels = audio.shape[1]
        mono = np.mean(audio, axis=1)

        technical = self._technical_metrics(audio, sr)
        loudness = self._loudness_metrics(audio, sr)
        dynamics = self._dynamics_metrics(audio, sr, loudness)
        stereo = self._stereo_metrics(audio, sr, profile)
        spectral = self._spectral_metrics(mono, sr)
        music = self._music_metrics(mono, sr)
        resonances = self._resonance_scan(mono, sr)
        issues = self._diagnose(
            technical=technical,
            loudness=loudness,
            dynamics=dynamics,
            stereo=stereo,
            spectral=spectral,
            music=music,
            resonances=resonances,
            profile=profile,
        )
        mastering_chain = self._build_mastering_chain(
            issues=issues,
            loudness=loudness,
            dynamics=dynamics,
            stereo=stereo,
            spectral=spectral,
            profile=profile,
        )
        score = self._score_readiness(issues, loudness, technical, dynamics, stereo, profile)
        executive = self._executive_summary(score, issues, loudness, dynamics, stereo, profile)

        report: Dict[str, Any] = {
            "schema": "sonic_ai.v2.mix_master_report",
            "engine": {
                "name": "Sonic AI V2 Engineering Analyzer",
                "version": "2.0.0-core",
                "mode": "deterministic_offline_analysis",
                "processing_ms": round((time.perf_counter() - started) * 1000.0, 2),
            },
            "file": {
                "name": os.path.basename(path),
                "sha256": file_hash,
                "duration_seconds": safe_float(duration, 3),
                "sample_rate_hz": sr,
                "channels": channels,
                "loader_notes": loader_notes,
            },
            "target_profile": profile.__dict__,
            "executive_summary": executive,
            "readiness": score,
            "measurements": {
                "technical": technical,
                "loudness": loudness,
                "dynamics": dynamics,
                "stereo": stereo,
                "spectral_balance": spectral,
                "music_detection": music,
                "resonance_scan": resonances,
            },
            "top_issues": issues[:8],
            "mastering_chain": mastering_chain,
            "deliverable_notes": self._deliverable_notes(profile),
        }

        if include_debug:
            report["debug"] = {
                "analysis_sr": self.analysis_sr,
                "true_peak_oversample": self.true_peak_oversample,
                "max_duration_seconds": self.max_duration_seconds,
            }

        return report

    def _load_audio(self, path: str) -> Tuple[np.ndarray, int, List[str]]:
        notes: List[str] = []
        try:
            data, sr = sf.read(path, dtype="float32", always_2d=True)
            notes.append("loaded_with_soundfile")
        except Exception as sf_error:
            # Fallback for formats that libsndfile may not decode in a given environment.
            y, sr = librosa.load(path, sr=None, mono=False)
            if y.ndim == 1:
                data = y.reshape(-1, 1).astype(np.float32)
            else:
                data = y.T.astype(np.float32)
            notes.append(f"soundfile_failed_fallback_librosa: {type(sf_error).__name__}")

        if data.ndim == 1:
            data = data.reshape(-1, 1)

        if data.shape[0] < 1024:
            raise ValueError("Audio file is too short for reliable engineering analysis.")

        if data.shape[1] > 2:
            notes.append(f"multichannel_downselected_first_2_of_{data.shape[1]}")
            data = data[:, :2]

        return data.astype(np.float32, copy=False), int(sr), notes

    def _limit_duration(self, audio: np.ndarray, sr: int) -> np.ndarray:
        max_samples = int(sr * self.max_duration_seconds)
        if audio.shape[0] > max_samples:
            return audio[:max_samples, :]
        return audio

    def _sanitize_audio(self, audio: np.ndarray) -> np.ndarray:
        audio = np.nan_to_num(audio, nan=0.0, posinf=0.0, neginf=0.0)
        return np.clip(audio, -4.0, 4.0).astype(np.float32, copy=False)

    def _hash_file(self, path: str) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    def _technical_metrics(self, audio: np.ndarray, sr: int) -> Dict[str, Any]:
        sample_peak = np.max(np.abs(audio), axis=0)
        sample_peak_db = [safe_float(v, 3) for v in db20(sample_peak + EPS)]
        global_peak_db = peak_dbfs(audio)
        clip_mask = np.abs(audio) >= 0.999
        clipped_samples = int(np.sum(clip_mask))
        clipped_percent = 100.0 * clipped_samples / float(audio.size)

        dc = np.mean(audio, axis=0)
        dc_db = [safe_float(v, 2) for v in db20(np.abs(dc) + EPS)]

        true_peak_db = self._true_peak_dbtp(audio)
        intersample_risk_db = true_peak_db - global_peak_db

        l_r_peak_delta_db: Optional[float] = None
        if audio.shape[1] == 2:
            l_r_peak_delta_db = safe_float(abs(sample_peak_db[0] - sample_peak_db[1]), 3)

        return {
            "sample_peak_dbfs": safe_float(global_peak_db, 3),
            "channel_peak_dbfs": sample_peak_db,
            "estimated_true_peak_dbtp": safe_float(true_peak_db, 3),
            "estimated_intersample_peak_risk_db": safe_float(intersample_risk_db, 3),
            "clipped_samples": clipped_samples,
            "clipped_percent": safe_float(clipped_percent, 5),
            "dc_offset": [safe_float(v, 7) for v in dc],
            "dc_offset_dbfs": dc_db,
            "left_right_peak_delta_db": l_r_peak_delta_db,
            "sample_rate_hz": sr,
            "bit_depth_note": "PCM bit depth is not inferred from float-decoded audio; inspect source metadata separately when needed.",
        }

    def _true_peak_dbtp(self, audio: np.ndarray) -> float:
        if self.true_peak_oversample <= 1:
            return peak_dbfs(audio)
        # Polyphase oversampling gives a stronger true-peak estimate than raw sample peak.
        oversampled = signal.resample_poly(audio, up=self.true_peak_oversample, down=1, axis=0)
        return peak_dbfs(oversampled)

    def _loudness_metrics(self, audio: np.ndarray, sr: int) -> Dict[str, Any]:
        meter = pyln.Meter(sr)
        try:
            integrated = float(meter.integrated_loudness(audio))
        except Exception:
            integrated = float("nan")

        short = self._window_loudness(audio, sr, window_s=3.0, hop_s=1.0)
        momentary = self._window_loudness(audio, sr, window_s=0.4, hop_s=0.2)

        def stats(values: np.ndarray) -> Dict[str, Optional[float]]:
            values = values[np.isfinite(values)]
            if values.size == 0:
                return {"min": None, "p10": None, "median": None, "p95": None, "max": None}
            return {
                "min": safe_float(np.min(values), 2),
                "p10": safe_float(np.percentile(values, 10), 2),
                "median": safe_float(np.median(values), 2),
                "p95": safe_float(np.percentile(values, 95), 2),
                "max": safe_float(np.max(values), 2),
            }

        short_stats = stats(short)
        momentary_stats = stats(momentary)
        lra = None
        if short_stats["p95"] is not None and short_stats["p10"] is not None:
            lra = safe_float(short_stats["p95"] - short_stats["p10"], 2)

        return {
            "integrated_lufs": safe_float(integrated, 2),
            "short_term_lufs": short_stats,
            "momentary_lufs": momentary_stats,
            "estimated_lra_lu": lra,
            "measurement_standard_note": "Integrated loudness is BS.1770-style via pyloudnorm; short/momentary values are windowed engineering estimates.",
        }

    def _window_loudness(self, audio: np.ndarray, sr: int, window_s: float, hop_s: float) -> np.ndarray:
        meter = pyln.Meter(sr)
        window = int(sr * window_s)
        hop = max(1, int(sr * hop_s))
        if audio.shape[0] < window:
            return np.asarray([], dtype=np.float32)

        values: List[float] = []
        for start in range(0, audio.shape[0] - window + 1, hop):
            chunk = audio[start : start + window]
            try:
                val = float(meter.integrated_loudness(chunk))
                if np.isfinite(val):
                    values.append(val)
            except Exception:
                continue
        return np.asarray(values, dtype=np.float32)

    def _dynamics_metrics(self, audio: np.ndarray, sr: int, loudness: Dict[str, Any]) -> Dict[str, Any]:
        mono = np.mean(audio, axis=1)
        global_rms = float(rms(mono))
        sample_peak = float(np.max(np.abs(mono)))
        crest_factor_db = float(db20(sample_peak / (global_rms + EPS)))

        frame = int(0.050 * sr)
        hop = int(0.025 * sr)
        if len(mono) < frame:
            frame_rms = np.asarray([global_rms])
        else:
            frame_rms = librosa.feature.rms(y=mono, frame_length=frame, hop_length=hop, center=False)[0]
        frame_db = db20(frame_rms + EPS)
        dynamic_spread = float(np.percentile(frame_db, 95) - np.percentile(frame_db, 10))

        onset_env = librosa.onset.onset_strength(y=self._analysis_mono(mono, sr), sr=self.analysis_sr)
        onset_frames = librosa.onset.onset_detect(onset_envelope=onset_env, sr=self.analysis_sr, units="frames")
        duration = len(mono) / float(sr)
        onset_density_per_sec = len(onset_frames) / max(duration, EPS)

        transient_strength = 0.0
        if onset_env.size:
            transient_strength = float(np.percentile(onset_env, 95) / (np.median(onset_env) + EPS))

        return {
            "rms_dbfs": safe_float(db20(global_rms + EPS), 3),
            "crest_factor_db": safe_float(crest_factor_db, 2),
            "frame_dynamic_spread_db": safe_float(dynamic_spread, 2),
            "onset_density_per_second": safe_float(onset_density_per_sec, 3),
            "transient_strength_index": safe_float(transient_strength, 3),
            "compression_read": self._compression_read(crest_factor_db, dynamic_spread, loudness),
        }

    def _analysis_mono(self, mono: np.ndarray, sr: int) -> np.ndarray:
        if sr == self.analysis_sr:
            return mono.astype(np.float32, copy=False)
        return librosa.resample(mono.astype(np.float32), orig_sr=sr, target_sr=self.analysis_sr)

    def _compression_read(
        self,
        crest_factor_db: float,
        dynamic_spread: float,
        loudness: Dict[str, Any],
    ) -> str:
        lufs = loudness.get("integrated_lufs")
        if lufs is not None and lufs > -8 and crest_factor_db < 6:
            return "over_limited_or_heavily_clipped"
        if crest_factor_db < 7 or dynamic_spread < 6:
            return "dense_limited"
        if crest_factor_db > 14 and dynamic_spread > 14:
            return "wide_dynamic_range"
        return "controlled"

    def _stereo_metrics(self, audio: np.ndarray, sr: int, profile: TargetProfile) -> Dict[str, Any]:
        if audio.shape[1] < 2:
            return {
                "is_stereo": False,
                "correlation_fullband": None,
                "mid_side_ratio_db": None,
                "low_band_side_mid_ratio_db": None,
                "mono_compatibility_risk": "unknown_mono_file",
            }

        left = audio[:, 0]
        right = audio[:, 1]
        corr = float(np.corrcoef(left, right)[0, 1]) if np.std(left) > EPS and np.std(right) > EPS else 1.0
        mid = (left + right) * 0.5
        side = (left - right) * 0.5
        ms_ratio = float(db20(float(rms(side)) / (float(rms(mid)) + EPS)))

        low_mid, low_side = self._low_band_mid_side(mid, side, sr, cutoff_hz=profile.mono_low_hz)
        low_side_mid = float(db20(float(rms(low_side)) / (float(rms(low_mid)) + EPS)))

        l_r_rms = db20(rms(audio, axis=0) + EPS)
        image_shift = float(l_r_rms[0] - l_r_rms[1])

        if corr < -0.1 or low_side_mid > -12:
            risk = "high"
        elif corr < 0.15 or low_side_mid > -18:
            risk = "medium"
        else:
            risk = "low"

        return {
            "is_stereo": True,
            "correlation_fullband": safe_float(corr, 3),
            "mid_side_ratio_db": safe_float(ms_ratio, 2),
            "low_band_side_mid_ratio_db": safe_float(low_side_mid, 2),
            "left_right_rms_delta_db": safe_float(image_shift, 2),
            "mono_compatibility_risk": risk,
            "mono_low_frequency_target_hz": profile.mono_low_hz,
        }

    def _low_band_mid_side(
        self,
        mid: np.ndarray,
        side: np.ndarray,
        sr: int,
        cutoff_hz: float,
    ) -> Tuple[np.ndarray, np.ndarray]:
        cutoff = min(cutoff_hz, sr * 0.45)
        sos = signal.butter(4, cutoff, btype="lowpass", fs=sr, output="sos")
        return signal.sosfiltfilt(sos, mid), signal.sosfiltfilt(sos, side)

    def _spectral_metrics(self, mono: np.ndarray, sr: int) -> Dict[str, Any]:
        nperseg = min(8192, max(1024, int(sr * 0.20)))
        freqs, psd = signal.welch(mono, fs=sr, nperseg=nperseg, noverlap=nperseg // 2)
        psd = np.maximum(psd, EPS)

        bands = {
            "sub_20_60_hz": (20, 60),
            "bass_60_120_hz": (60, 120),
            "low_mid_120_250_hz": (120, 250),
            "mud_250_500_hz": (250, 500),
            "body_500_2000_hz": (500, 2000),
            "presence_2000_5000_hz": (2000, 5000),
            "harsh_5000_8000_hz": (5000, 8000),
            "air_8000_16000_hz": (8000, 16000),
            "ultra_16000_20000_hz": (16000, min(20000, sr / 2 - 1)),
        }

        band_power: Dict[str, Optional[float]] = {}
        for name, (lo, hi) in bands.items():
            if hi <= lo or lo >= sr / 2:
                band_power[name] = None
                continue
            mask = (freqs >= lo) & (freqs < hi)
            if not np.any(mask):
                band_power[name] = None
                continue
            band_power[name] = safe_float(db10(np.mean(psd[mask]) + EPS), 2)

        valid = np.asarray([v for v in band_power.values() if v is not None], dtype=np.float32)
        tilt_db_per_octave = self._spectral_tilt(freqs, psd)

        y_analysis = self._analysis_mono(mono, sr)
        centroid = librosa.feature.spectral_centroid(y=y_analysis, sr=self.analysis_sr)[0]
        rolloff = librosa.feature.spectral_rolloff(y=y_analysis, sr=self.analysis_sr, roll_percent=0.85)[0]
        flatness = librosa.feature.spectral_flatness(y=y_analysis)[0]

        return {
            "band_power_db": band_power,
            "band_power_relative_to_mean_db": {
                k: (safe_float(v - float(np.mean(valid)), 2) if v is not None and valid.size else None)
                for k, v in band_power.items()
            },
            "spectral_tilt_db_per_octave": safe_float(tilt_db_per_octave, 3),
            "spectral_centroid_hz_median": safe_float(np.median(centroid), 1),
            "spectral_rolloff_85_hz_median": safe_float(np.median(rolloff), 1),
            "spectral_flatness_median": safe_float(np.median(flatness), 5),
            "tonal_balance_read": self._tonal_balance_read(band_power),
        }

    def _spectral_tilt(self, freqs: np.ndarray, psd: np.ndarray) -> float:
        mask = (freqs >= 80) & (freqs <= 16000)
        if np.sum(mask) < 10:
            return 0.0
        x = np.log2(freqs[mask])
        y = db10(psd[mask])
        slope, _ = np.polyfit(x, y, 1)
        return float(slope)

    def _tonal_balance_read(self, band_power: Dict[str, Optional[float]]) -> str:
        def rel(a: str, b: str) -> Optional[float]:
            if band_power.get(a) is None or band_power.get(b) is None:
                return None
            return float(band_power[a] - band_power[b])

        mud_vs_body = rel("mud_250_500_hz", "body_500_2000_hz")
        harsh_vs_body = rel("harsh_5000_8000_hz", "body_500_2000_hz")
        sub_vs_body = rel("sub_20_60_hz", "body_500_2000_hz")
        air_vs_body = rel("air_8000_16000_hz", "body_500_2000_hz")

        if mud_vs_body is not None and mud_vs_body > 5:
            return "mud_forward"
        if harsh_vs_body is not None and harsh_vs_body > 4:
            return "upper_harshness_forward"
        if sub_vs_body is not None and sub_vs_body > 6:
            return "sub_heavy"
        if air_vs_body is not None and air_vs_body < -10:
            return "dark_top_end"
        return "balanced_by_broadband_measurement"

    def _music_metrics(self, mono: np.ndarray, sr: int) -> Dict[str, Any]:
        y = self._analysis_mono(mono, sr)
        tempo: Optional[float] = None
        beat_count = 0
        beat_confidence = 0.0

        try:
            tempo_raw, beat_frames = librosa.beat.beat_track(y=y, sr=self.analysis_sr, trim=False)
            tempo = float(np.ravel(tempo_raw)[0])
            beat_count = int(len(beat_frames))
            onset_env = librosa.onset.onset_strength(y=y, sr=self.analysis_sr)
            if beat_count > 3 and onset_env.size:
                beat_confidence = clamp01(float(np.mean(onset_env[beat_frames]) / (np.percentile(onset_env, 95) + EPS)))
        except Exception:
            tempo = None

        key_result = self._estimate_key(y, self.analysis_sr)

        return {
            "tempo_bpm": safe_float(tempo, 2) if tempo is not None else None,
            "beat_count": beat_count,
            "beat_confidence": safe_float(beat_confidence, 3),
            "estimated_key": key_result,
            "music_detection_note": "Tempo and key are MIR estimates; trust increases with stable drums and harmonic content.",
        }

    def _estimate_key(self, y: np.ndarray, sr: int) -> Dict[str, Any]:
        try:
            chroma = librosa.feature.chroma_cqt(y=y, sr=sr)
            chroma_mean = np.mean(chroma, axis=1)
            chroma_norm = chroma_mean / (np.linalg.norm(chroma_mean) + EPS)

            major_profile = np.asarray([6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88])
            minor_profile = np.asarray([6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17])
            major_profile = major_profile / np.linalg.norm(major_profile)
            minor_profile = minor_profile / np.linalg.norm(minor_profile)

            candidates: List[Tuple[str, str, float]] = []
            for i, note in enumerate(A4_NOTE_NAMES):
                candidates.append((note, "major", float(np.corrcoef(chroma_norm, np.roll(major_profile, i))[0, 1])))
                candidates.append((note, "minor", float(np.corrcoef(chroma_norm, np.roll(minor_profile, i))[0, 1])))

            candidates.sort(key=lambda x: x[2], reverse=True)
            best = candidates[0]
            second = candidates[1]
            confidence = clamp01((best[2] - second[2] + 0.05) / 0.25)

            return {
                "key": f"{best[0]} {best[1]}",
                "confidence": safe_float(confidence, 3),
                "top_candidates": [
                    {"key": f"{n} {m}", "score": safe_float(s, 4)}
                    for n, m, s in candidates[:5]
                ],
            }
        except Exception as exc:
            return {
                "key": None,
                "confidence": 0.0,
                "error": type(exc).__name__,
            }

    def _resonance_scan(self, mono: np.ndarray, sr: int) -> Dict[str, Any]:
        n_fft = 8192
        hop = 2048
        y = self._analysis_mono(mono, sr)
        sr2 = self.analysis_sr

        stft = np.abs(librosa.stft(y, n_fft=n_fft, hop_length=hop)) ** 2
        freqs = librosa.fft_frequencies(sr=sr2, n_fft=n_fft)
        mean_power_db = db10(np.mean(stft, axis=1) + EPS)

        mask = (freqs >= 80) & (freqs <= min(12000, sr2 / 2 - 1))
        f = freqs[mask]
        p = mean_power_db[mask]
        if f.size < 10:
            return {"top_resonant_regions": [], "note": "insufficient_frequency_resolution"}

        smooth = signal.medfilt(p, kernel_size= nine_safe_kernel(min(101, max(5, int(len(p) * 0.03)))))
        excess = p - smooth
        peaks, props = signal.find_peaks(excess, height=4.0, distance=8)

        candidates = []
        if len(peaks):
            order = np.argsort(props["peak_heights"])[::-1][:8]
            for idx in order:
                peak_idx = peaks[idx]
                candidates.append(
                    {
                        "frequency_hz": safe_float(f[peak_idx], 1),
                        "excess_db": safe_float(props["peak_heights"][idx], 2),
                        "action": self._resonance_action(float(f[peak_idx]), float(props["peak_heights"][idx])),
                    }
                )

        return {
            "top_resonant_regions": candidates,
            "threshold_excess_db": 4.0,
            "note": "Regions are not automatic EQ commands; verify with bypass and context.",
        }

    def _resonance_action(self, freq: float, excess_db: float) -> str:
        q = "Q 2.0-5.0"
        amount = min(3.0, max(0.8, excess_db * 0.35))
        if freq < 180:
            return f"Check kick/bass note buildup; dynamic cut around {freq:.0f} Hz, {q}, -{amount:.1f} dB only if masking is audible."
        if freq < 500:
            return f"Check mud/box buildup; narrow bell or dynamic EQ around {freq:.0f} Hz, {q}, -{amount:.1f} dB."
        if freq < 3000:
            return f"Check vocal/instrument nasal buildup; bell around {freq:.0f} Hz, {q}, -{amount:.1f} dB."
        return f"Check harsh or whistle tone; dynamic bell around {freq:.0f} Hz, {q}, -{amount:.1f} dB."

    def _diagnose(
        self,
        technical: Dict[str, Any],
        loudness: Dict[str, Any],
        dynamics: Dict[str, Any],
        stereo: Dict[str, Any],
        spectral: Dict[str, Any],
        music: Dict[str, Any],
        resonances: Dict[str, Any],
        profile: TargetProfile,
    ) -> List[Dict[str, Any]]:
        issues: List[Dict[str, Any]] = []

        def add(
            code: str,
            severity: Literal["critical", "high", "medium", "low"],
            title: str,
            evidence: Dict[str, Any],
            why: str,
            action: str,
            confidence: float,
        ) -> None:
            weights = {"critical": 100, "high": 75, "medium": 45, "low": 20}
            issues.append(
                {
                    "code": code,
                    "severity": severity,
                    "priority": weights[severity],
                    "title": title,
                    "evidence": evidence,
                    "why_it_matters": why,
                    "recommended_action": action,
                    "confidence": safe_float(confidence, 3),
                }
            )

        if technical["clipped_samples"] > 0:
            add(
                "CLIPPING_SAMPLE_PEAK",
                "critical",
                "Sample clipping detected",
                {"clipped_samples": technical["clipped_samples"], "clipped_percent": technical["clipped_percent"]},
                "Hard clipping can create non-musical distortion and make downstream limiting less predictable.",
                "Lower source gain or remove clipping before mastering. Re-export with clean headroom.",
                0.98,
            )

        if technical["estimated_true_peak_dbtp"] is not None and technical["estimated_true_peak_dbtp"] > profile.true_peak_max_dbtp:
            add(
                "TRUE_PEAK_OVERS",
                "high",
                "True peak exceeds target ceiling",
                {"estimated_true_peak_dbtp": technical["estimated_true_peak_dbtp"], "target_max_dbtp": profile.true_peak_max_dbtp},
                "Inter-sample peaks can distort after codec conversion or streaming normalization.",
                f"Set final limiter ceiling to {profile.true_peak_max_dbtp:.1f} dBTP and reduce limiter input until overs clear.",
                0.86,
            )

        lufs = loudness.get("integrated_lufs")
        if lufs is not None:
            if lufs > profile.integrated_lufs_max:
                add(
                    "LOUDNESS_OVER_TARGET",
                    "medium",
                    "Integrated loudness is hotter than target profile",
                    {"integrated_lufs": lufs, "target_range": [profile.integrated_lufs_min, profile.integrated_lufs_max]},
                    "Over-limiting can flatten punch and reduce translation even when it sounds loud in the room.",
                    "Back off limiter input or bus compression until the master sits inside target loudness range.",
                    0.82,
                )
            elif lufs < profile.integrated_lufs_min:
                add(
                    "LOUDNESS_UNDER_TARGET",
                    "medium",
                    "Integrated loudness is below target profile",
                    {"integrated_lufs": lufs, "target_range": [profile.integrated_lufs_min, profile.integrated_lufs_max]},
                    "The track may feel smaller than reference masters at matched playback intent.",
                    "Raise controlled gain through saturation/compression/limiting rather than only adding limiter gain.",
                    0.76,
                )

        if dynamics["crest_factor_db"] is not None and dynamics["crest_factor_db"] < profile.crest_factor_min_db:
            add(
                "LOW_CREST_FACTOR",
                "high",
                "Crest factor is too low for punch",
                {"crest_factor_db": dynamics["crest_factor_db"], "minimum": profile.crest_factor_min_db},
                "Low crest factor often means kicks, snares, and transients have been flattened.",
                "Reduce limiter drive, use slower attack bus compression, or restore drum transient envelope before final limiting.",
                0.8,
            )

        if stereo.get("is_stereo") and stereo.get("mono_compatibility_risk") in {"medium", "high"}:
            sev = "high" if stereo["mono_compatibility_risk"] == "high" else "medium"
            add(
                "MONO_COMPATIBILITY_RISK",
                sev,  # type: ignore[arg-type]
                "Mono compatibility / phase risk",
                {
                    "correlation_fullband": stereo.get("correlation_fullband"),
                    "low_band_side_mid_ratio_db": stereo.get("low_band_side_mid_ratio_db"),
                },
                "Stereo low-end or negative correlation can collapse when played in mono systems.",
                f"Mono the low end below {profile.mono_low_hz:.0f} Hz and check the side channel for bass content.",
                0.83,
            )

        band_rel = spectral.get("band_power_relative_to_mean_db", {})
        if band_rel.get("mud_250_500_hz") is not None and band_rel["mud_250_500_hz"] > 4:
            add(
                "MUD_BUILDUP_250_500",
                "medium",
                "Mud buildup around 250-500 Hz",
                {"relative_band_power_db": band_rel["mud_250_500_hz"]},
                "Excess low-mid energy can make the mix cloudy and reduce perceived loudness.",
                "Use small corrective cuts or dynamic EQ in 250-500 Hz; avoid gutting warmth.",
                0.72,
            )

        if band_rel.get("harsh_5000_8000_hz") is not None and band_rel["harsh_5000_8000_hz"] > 4:
            add(
                "HARSHNESS_5_8K",
                "medium",
                "Potential harshness in 5-8 kHz",
                {"relative_band_power_db": band_rel["harsh_5000_8000_hz"]},
                "This range can fatigue listeners and make limiting sound brittle.",
                "Use dynamic EQ/de-essing style control around 5-8 kHz before final limiting.",
                0.67,
            )

        if band_rel.get("sub_20_60_hz") is not None and band_rel["sub_20_60_hz"] > 7:
            add(
                "SUB_EXCESS",
                "medium",
                "Sub band is heavy relative to the rest of the spectrum",
                {"relative_band_power_db": band_rel["sub_20_60_hz"]},
                "Too much sub steals limiter headroom and weakens perceived loudness on small speakers.",
                "Tighten 808/kick overlap, high-pass non-bass elements, and control sub with dynamic EQ.",
                0.69,
            )

        if band_rel.get("air_8000_16000_hz") is not None and band_rel["air_8000_16000_hz"] < -8:
            add(
                "DARK_TOP_END",
                "low",
                "Top end / air may be restrained",
                {"relative_band_power_db": band_rel["air_8000_16000_hz"]},
                "A dark top end can make the track feel less finished next to commercial references.",
                "Try subtle high-shelf or harmonic excitation above 8-10 kHz if cymbals/vocals need lift.",
                0.55,
            )

        dc_values = [abs(v) for v in technical.get("dc_offset", []) if v is not None]
        if dc_values and max(dc_values) > 0.005:
            add(
                "DC_OFFSET",
                "low",
                "DC offset detected",
                {"dc_offset": technical.get("dc_offset")},
                "DC offset reduces clean headroom and can cause asymmetric processing behavior.",
                "Apply DC offset removal before dynamics processing.",
                0.9,
            )

        res = resonances.get("top_resonant_regions", [])
        if res:
            worst = res[0]
            if worst.get("excess_db", 0) > 6:
                add(
                    "NARROW_RESONANCE",
                    "medium",
                    "Narrow resonant buildup detected",
                    worst,
                    "Narrow resonances can jump out after compression/limiting.",
                    worst.get("action", "Verify with a narrow sweep and dynamic EQ if audible."),
                    0.62,
                )

        issues.sort(key=lambda item: item["priority"], reverse=True)
        return issues

    def _build_mastering_chain(
        self,
        issues: List[Dict[str, Any]],
        loudness: Dict[str, Any],
        dynamics: Dict[str, Any],
        stereo: Dict[str, Any],
        spectral: Dict[str, Any],
        profile: TargetProfile,
    ) -> Dict[str, Any]:
        codes = {i["code"] for i in issues}
        lufs = loudness.get("integrated_lufs")
        target_mid = (profile.integrated_lufs_min + profile.integrated_lufs_max) / 2.0
        required_gain = None if lufs is None else safe_float(target_mid - float(lufs), 2)

        chain: List[Dict[str, Any]] = []

        chain.append(
            {
                "slot": 1,
                "processor": "Utility / Gain Stage",
                "purpose": "Set clean mastering input gain before tone or dynamics.",
                "starting_settings": {
                    "input_trim_db": 0.0,
                    "target_pre_limiter_peak_dbfs": -6.0 if profile.name == "premaster" else -3.0,
                    "dc_offset_removal": "on" if "DC_OFFSET" in codes else "optional",
                },
            }
        )

        corrective_moves: List[str] = []
        if "MUD_BUILDUP_250_500" in codes:
            corrective_moves.append("Dynamic bell: 250-500 Hz, Q 1.0-2.5, -1.0 to -2.5 dB when masking blooms.")
        if "HARSHNESS_5_8K" in codes:
            corrective_moves.append("Dynamic bell/de-ess: 5-8 kHz, Q 1.5-4.0, -0.8 to -2.0 dB on sharp hits.")
        if "SUB_EXCESS" in codes:
            corrective_moves.append("Dynamic low shelf or bell: 35-70 Hz, -0.8 to -2.5 dB only on sustained sub overload.")
        if not corrective_moves:
            corrective_moves.append("No forced corrective EQ; use reference-based micro moves only.")

        chain.append(
            {
                "slot": 2,
                "processor": "Corrective EQ / Dynamic EQ",
                "purpose": "Remove frequency problems before compression and limiting amplify them.",
                "starting_settings": {
                    "high_pass": "20-28 Hz, 12 dB/oct, only if inaudible rumble exists",
                    "moves": corrective_moves,
                },
            }
        )

        crest = dynamics.get("crest_factor_db")
        if crest is not None and crest < profile.crest_factor_min_db:
            comp = {
                "ratio": "1.2:1 to 1.5:1",
                "attack_ms": "30-60",
                "release_ms": "auto or 120-250",
                "gain_reduction_target_db": "0.5-1.0",
                "note": "Compression should be nearly invisible; restore punch before adding loudness.",
            }
        else:
            comp = {
                "ratio": "1.5:1 to 2.0:1",
                "attack_ms": "20-40",
                "release_ms": "auto or tempo-synced 80-180",
                "gain_reduction_target_db": "1.0-2.0",
                "note": "Use for glue, not loudness. Bypass-match level.",
            }

        chain.append(
            {
                "slot": 3,
                "processor": "Bus Compressor",
                "purpose": "Glue the record while preserving transient identity.",
                "starting_settings": comp,
            }
        )

        chain.append(
            {
                "slot": 4,
                "processor": "Harmonic Saturation / Soft Clip",
                "purpose": "Increase density and perceived loudness before the limiter.",
                "starting_settings": {
                    "drive": "low",
                    "mix": "5-15%",
                    "oversampling": "on",
                    "watch": "kick/808 distortion, vocal grit, cymbal brittleness",
                },
            }
        )

        stereo_settings = {
            "mono_below_hz": profile.mono_low_hz,
            "side_low_cut": f"{profile.mono_low_hz:.0f} Hz" if stereo.get("is_stereo") else "not_applicable_mono",
            "width_change": "do_not_widen_until_mono_passes" if "MONO_COMPATIBILITY_RISK" in codes else "optional +0% to +8% above 4 kHz",
        }
        chain.append(
            {
                "slot": 5,
                "processor": "Stereo Image / Mid-Side Control",
                "purpose": "Stabilize low end and preserve mono translation.",
                "starting_settings": stereo_settings,
            }
        )

        chain.append(
            {
                "slot": 6,
                "processor": "Final Limiter / True Peak Limiter",
                "purpose": "Final loudness and ceiling control.",
                "starting_settings": {
                    "ceiling_dbtp": profile.true_peak_max_dbtp,
                    "target_integrated_lufs_range": [profile.integrated_lufs_min, profile.integrated_lufs_max],
                    "estimated_gain_needed_db": required_gain,
                    "oversampling": "4x or higher",
                    "max_gain_reduction_db": "2-4 dB unless intentionally aggressive",
                },
            }
        )

        return {
            "philosophy": "Correct technical problems before loudness. Gain match every stage. Verify against references.",
            "chain": chain,
            "print_checks": [
                "Bypass-match each processor.",
                "Check mono below the target low-frequency boundary.",
                "Export 24-bit WAV premaster and final master.",
                "Confirm no sample clipping and true peak below ceiling.",
                "Reference at matched LUFS, not louder-is-better.",
            ],
        }

    def _score_readiness(
        self,
        issues: List[Dict[str, Any]],
        loudness: Dict[str, Any],
        technical: Dict[str, Any],
        dynamics: Dict[str, Any],
        stereo: Dict[str, Any],
        profile: TargetProfile,
    ) -> Dict[str, Any]:
        score = 100.0
        for issue in issues:
            if issue["severity"] == "critical":
                score -= 28
            elif issue["severity"] == "high":
                score -= 17
            elif issue["severity"] == "medium":
                score -= 9
            elif issue["severity"] == "low":
                score -= 4

        score = max(0.0, min(100.0, score))

        if score >= 85:
            status = "master_ready_with_minor_checks"
        elif score >= 70:
            status = "close_needs_targeted_fixes"
        elif score >= 50:
            status = "mix_revision_recommended_before_mastering"
        else:
            status = "not_master_ready"

        return {
            "score_0_100": safe_float(score, 1),
            "status": status,
            "critical_count": sum(1 for i in issues if i["severity"] == "critical"),
            "high_count": sum(1 for i in issues if i["severity"] == "high"),
            "medium_count": sum(1 for i in issues if i["severity"] == "medium"),
            "low_count": sum(1 for i in issues if i["severity"] == "low"),
            "target_profile": profile.name,
        }

    def _executive_summary(
        self,
        score: Dict[str, Any],
        issues: List[Dict[str, Any]],
        loudness: Dict[str, Any],
        dynamics: Dict[str, Any],
        stereo: Dict[str, Any],
        profile: TargetProfile,
    ) -> Dict[str, Any]:
        top = issues[0]["title"] if issues else "No major engineering issue detected"
        return {
            "status": score["status"],
            "headline": top,
            "mastering_read": self._mastering_read(loudness, dynamics, stereo, profile),
            "first_move": issues[0]["recommended_action"] if issues else "Run matched-reference listening and keep moves minimal.",
            "lufs": loudness.get("integrated_lufs"),
            "crest_factor_db": dynamics.get("crest_factor_db"),
            "mono_risk": stereo.get("mono_compatibility_risk"),
        }

    def _mastering_read(
        self,
        loudness: Dict[str, Any],
        dynamics: Dict[str, Any],
        stereo: Dict[str, Any],
        profile: TargetProfile,
    ) -> str:
        lufs = loudness.get("integrated_lufs")
        crest = dynamics.get("crest_factor_db")
        mono_risk = stereo.get("mono_compatibility_risk")

        problems = []
        if lufs is not None and not (profile.integrated_lufs_min <= lufs <= profile.integrated_lufs_max):
            problems.append("loudness outside target")
        if crest is not None and crest < profile.crest_factor_min_db:
            problems.append("reduced punch")
        if mono_risk in {"medium", "high"}:
            problems.append("mono/stereo risk")

        if not problems:
            return "Track is technically close to target; use conservative mastering."
        return "Fix before final loudness: " + ", ".join(problems) + "."

    def _deliverable_notes(self, profile: TargetProfile) -> Dict[str, Any]:
        return {
            "recommended_final_wav": "24-bit WAV, source sample rate, no normalization after limiter",
            "recommended_streaming_ceiling": f"{profile.true_peak_max_dbtp:.1f} dBTP",
            "quality_control": [
                "Listen at low volume for balance.",
                "Check mono playback.",
                "Check car/small speaker translation.",
                "Compare against two commercial references at matched loudness.",
            ],
        }


def nine_safe_kernel(value: int) -> int:
    value = max(3, int(value))
    if value % 2 == 0:
        value += 1
    return value
