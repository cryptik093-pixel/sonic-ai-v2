
from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path
from typing import Literal

import orjson
from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.responses import ORJSONResponse
from starlette.concurrency import run_in_threadpool

from sonic_v2.engine import SonicV2Analyzer, TARGET_PROFILES


MAX_UPLOAD_MB = 250
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024
ALLOWED_EXTENSIONS = {".wav", ".aif", ".aiff", ".flac", ".ogg", ".mp3", ".m4a"}


app = FastAPI(
    title="Sonic AI V2",
    description="High-performance audio engineering, post-production, and mastering-chain analyzer.",
    version="2.0.0",
    default_response_class=ORJSONResponse,
)

analyzer = SonicV2Analyzer(
    analysis_sr=22050,
    true_peak_oversample=4,
    max_duration_seconds=900,
)


@app.get("/health")
def health() -> dict:
    return {
        "status": "online",
        "service": "sonic-ai-v2",
        "version": "2.0.0",
        "profiles": list(TARGET_PROFILES.keys()),
    }


@app.post("/api/v2/analyze")
async def analyze_audio(
    file: UploadFile = File(...),
    target_profile: str = Query("modern_hiphop_master", enum=list(TARGET_PROFILES.keys())),
    include_debug: bool = Query(False),
):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=415,
            detail={
                "error": "unsupported_file_type",
                "allowed": sorted(ALLOWED_EXTENSIONS),
                "received": suffix,
            },
        )

    with tempfile.TemporaryDirectory(prefix="sonic_v2_") as temp_dir:
        temp_path = Path(temp_dir) / f"upload{suffix}"
        size = 0

        try:
            with temp_path.open("wb") as out:
                while True:
                    chunk = await file.read(1024 * 1024)
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > MAX_UPLOAD_BYTES:
                        raise HTTPException(
                            status_code=413,
                            detail={
                                "error": "file_too_large",
                                "max_upload_mb": MAX_UPLOAD_MB,
                            },
                        )
                    out.write(chunk)

            report = await run_in_threadpool(
                analyzer.analyze_file,
                str(temp_path),
                target_profile,
                include_debug,
            )
            return report

        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(
                status_code=422,
                detail={
                    "error": "analysis_failed",
                    "message": str(exc),
                    "type": type(exc).__name__,
                },
            ) from exc
        finally:
            await file.close()


@app.get("/api/v2/profiles")
def profiles() -> dict:
    return {
        name: profile.__dict__
        for name, profile in TARGET_PROFILES.items()
    }


def dumps(obj):
    return orjson.dumps(obj, option=orjson.OPT_INDENT_2).decode("utf-8")
